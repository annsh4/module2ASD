// PP-11, Shutko Antony, V3(20), num1
package com.company;

import java.util.Scanner;

public class modul2
{
    static int getInt()
    {
        int choise_num;
        while (true)
        {
            final Scanner num = new Scanner(System.in);
            if (num.hasNextInt())
            {
                choise_num = num.nextInt();
                break;
            }
            System.out.println("it is not integer");
        }
        return choise_num;
    }

    static public void main(String []args)
    {
        int N, Add;
        System.out.println("enter number elements of the list");
        N = getInt();
        System.out.println("enter number of addons");
        Add = getInt();
        Node first = new Node();
        Node node = new Node();
        node = first;
        int el;
        for (int i=0; i<N; i++)
        {
            System.out.println("enter element");
            el = getInt();
            node.setElement(el);
            node.setNext(new Node());
            node.getNext().setPast(node);
            node = node.getNext();
        }
        Node n = first;
        do
        {
            System.out.println(n.getElement());
            n=n.getNext();
        }
        while (n.getNext()!=null);
        for (int i=0; i<Add; i++)
        {
            System.out.println("enter element");
            el = getInt();
            node.setElement(el);
            node.setNext(new Node());
            node.getNext().setPast(node);
            node = node.getNext();
        }
        int s = first.getElement();
        for (int i=0; i<N+Add; i++)
        {
            n=first;
            while (n.getNext()!=null)
            {
                if(n.getElement()>n.getNext().getElement())
                {
                    s=n.getElement();
                    n.setElement(n.getNext().getElement());
                    n.getNext().setElement(s);
                }
                n=n.getNext();
            }
        }
        n = first;
        do
        {
            System.out.println(n.getElement());
            n=n.getNext();
        }
        while (n.getNext()!=null);
    }
}

class Node
{
    private int element;
    private Node next;
    private Node past;

    public int getElement()
    {
        return element;
    }

    public void setElement(int e)
    {
        element = e;
    }

    public Node getNext()
    {
        return next;
    }

    public void setNext(Node n)
    {
        next = n;
    }

    public Node getPast()
    {
        return past;
    }

    public void setPast(Node p)
    {
        past = p;
    }
}